/*
 * Intro.cpp
 *
 *  Created on: Sep 14, 2023
 *      Author: richard
 */

#include <iostream>

using namespace std;

int main(void) {
	int myInt = 45;//example integer number
	float myFloat = myInt;//example float number
	cout << "Welcome to the class." << endl << "Your int number is " << myInt;
	cout << "." << endl << "Your float number is " << myFloat << "." << endl;
}




#include <iostream>
using namespace std;

int main(void) {
	int myInt = 45;//example integer number
	float myFloat = 45.5;//example float number
	cout << "Welcome to the class." << endl << "Your int number is " << myInt;
	cout << "." << endl << "Your float number is " << myFloat << "." << endl;

	return 0;//end with a success response
}//end main function

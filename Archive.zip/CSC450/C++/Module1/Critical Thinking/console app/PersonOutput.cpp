#include <iostream>

using namespace std;

int main() {
	string nameFirst = "Mickey";
	string nameLast = "Mouse";
	string address = "1675 North Buena Vista Drive";
	string city = "Lake Buena Vista, Florida";
	string zipCode = "32830";
	
	cout << "The person's name is " << nameFirst << " " << nameLast << "." << endl;
	cout << "The person's address is " << address << " in " << city << "and the zip code is ";
	cout << zipCode << endl;
	
	return  0;
}//end main